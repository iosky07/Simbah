public class TabelDataMitra {

    int kecamatan;
    String id, mitra, ketua, alamat;

    public TabelDataMitra(int kecamatan, String id, String mitra, String ketua, String alamat) {
        this.kecamatan = kecamatan;
        this.id = id;
        this.mitra = mitra;
        this.ketua = ketua;
        this.alamat = alamat;
    }

    public int getKecamatan() {
        return kecamatan;
    }

    public String getId() {
        return id;
    }

    public String getMitra() {
        return mitra;
    }

    public String getKetua() {
        return ketua;
    }

    public String getAlamat() {
        return alamat;
    }
}
