//import javafx.event.ActionEvent;
//
//public class Dashboard {
//    public void tombol(ActionEvent event){
//        Helper.changePage(event,"dashboard");
//    }
//}

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class Dashboard implements Initializable {

    @FXML
    private TableView<TabelDataSampah> tabel_dashboard;

    @FXML
    private TableColumn<TabelDataSampah, String> col_id_sm;

    @FXML
    private TableColumn<TabelDataSampah, String> col_nama_tpa;

    @FXML
    private TableColumn<TabelDataSampah, Integer> col_kecamatan;

    @FXML
    private TableColumn<TabelDataSampah, String> col_tanggal_masuk;

    @FXML
    private TableColumn<TabelDataSampah, Integer> col_jumlah;

    @FXML
    private TableColumn<TabelDataSampah, String> col_no_truk;

    @FXML
    private Button tambahData;

    @FXML
    private Button editSampah;

    @FXML
    private Button logout;

    @FXML
    private Button datasampah;

    @FXML
    private Button permintaan;

    @FXML
    private Button menuProfil;

    @FXML
    private Button mitra;

    @FXML
    void OnDataSampahMenu(ActionEvent event) {
        Helper.changePage(event,"menu_data_sampah");
    }

    @FXML
    void OnEditSampah(ActionEvent event) {
        Helper.changePage(event,"edit_sampah_dashboard");
    }

    @FXML
    void OnLogout(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void OnMitraMenu(ActionEvent event) { Helper.changePage(event,"menu_mitra"); }

    @FXML
    void OnPermintaanMenu(ActionEvent event) {
        Helper.changePage(event,"menu_permintaan");
    }

    @FXML
    void OnProfilTPAMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

    @FXML
    void OnTambahSampah(ActionEvent event) {
        Helper.changePage(event,"tambah_sampah_dashboard");
    }

    ObservableList<TabelDataSampah> listM;

    int index = -1;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement ps = null;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        col_id_sm.setCellValueFactory(new PropertyValueFactory<TabelDataSampah, String>("id"));
        col_nama_tpa.setCellValueFactory(new PropertyValueFactory<TabelDataSampah, String>("nama"));
        col_kecamatan.setCellValueFactory(new PropertyValueFactory<TabelDataSampah, Integer>("kecamatan"));
        col_tanggal_masuk.setCellValueFactory(new PropertyValueFactory<TabelDataSampah, String>("tanggal"));
        col_jumlah.setCellValueFactory(new PropertyValueFactory<TabelDataSampah, Integer>("jumlah"));
        col_no_truk.setCellValueFactory(new PropertyValueFactory<TabelDataSampah, String>("noTruk"));

        listM = GetDataTabel.getDataDashboard();
        System.out.println(listM.get(0).getNama());
        tabel_dashboard.setItems(listM);
//        ResultSet rs = Helper.execute( "SELECT * FROM `datasampah`");
//        while(true){
//            try {
//                if (!rs.next()) break;
//            } catch (SQLException throwables) {
//                throwables.printStackTrace();
//            }
//            try {
//                System.out.println(rs.getString("id_sm"));
//                System.out.println(rs.getString("nama_tpa"));
//                System.out.println(rs.getString("tanggal_masuk"));
//                System.out.println(rs.getString("jumlah_sm"));
//                System.out.println(rs.getString("no_truk"));
//                System.out.println(rs.getString("id_kecamatan"));
//            } catch (SQLException throwables) {
//                throwables.printStackTrace();
//            }

        }
    }
