public class TabelDataSampah {

    int kecamatan, jumlah;
    String nama, id, noTruk,tanggal;

    public TabelDataSampah(int kecamatan, int jumlah, String nama, String id, String noTruk, String tanggal) {
        this.kecamatan = kecamatan;
        this.jumlah = jumlah;
        this.nama = nama;
        this.id = id;
        this.noTruk = noTruk;
        this.tanggal = tanggal;
    }

    public int getKecamatan() {
        return kecamatan;
    }

    public void setKecamatan(int kecamatan) {
        this.kecamatan = kecamatan;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNoTruk() {
        return noTruk;
    }

    public void setNoTruk(String noTruk) {
        this.noTruk = noTruk;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }
}
