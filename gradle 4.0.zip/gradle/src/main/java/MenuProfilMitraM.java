import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MenuProfilMitraM {

    @FXML
    private Button logoutM;

    @FXML
    private Button datasampahM;

    @FXML
    private Button permintaanM;

    @FXML
    private Button menuProfilM;

    @FXML
    private Button produksiM;

    @FXML
    private Button ubahPassM;

    @FXML
    void OnDataProduksiM(ActionEvent event) {
        Helper.changePage(event,"data_produksi_sampah_m");
    }

    @FXML
    void OnDataSampahM(ActionEvent event) {
        Helper.changePage(event,"data_sampah_m");
    }

    @FXML
    void OnLogoutM(ActionEvent event) {
        Helper.changePage(event,"loginpage_m");
    }

    @FXML
    void OnProfilMitraMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_mitra_m");
    }

    @FXML
    void OnRiwayatMenuM(ActionEvent event) {
        Helper.changePage(event,"menu_riwayat_permintaan_m");
    }

    @FXML
    void UbahPass(ActionEvent event) {
        Helper.changePage(event,"ubah_pass_m");
    }

}
