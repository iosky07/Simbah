import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class LoginpageM {

    @FXML
    private Button btnmasuk;

    @FXML
    private Button switchAdmin;

    @FXML
    void OnAdminLogin(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void masukDashboard(ActionEvent event) {
        Helper.changePage(event,"data_sampah_m");
    }

}
