import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MenuDataSampah {

    @FXML
    private Button logout;

    @FXML
    private Button datasampah;

    @FXML
    private Button permintaan;

    @FXML
    private Button mitra;

    @FXML
    private Button dataJumlahSampah;

    @FXML
    private Button dataPengelompokan;

    @FXML
    private Button menuProfil;

    @FXML
    private Button dataKeluarS;

    @FXML
    private Button dashboard;

    @FXML
    void OnDashboard(ActionEvent event) {
        Helper.changePage(event,"dashboard");
    }

    @FXML
    void OnDataJumlahS(ActionEvent event) {
        Helper.changePage(event,"data_jumlah_sampah");
    }

    @FXML
    void OnDataKeluarS(ActionEvent event) {
        Helper.changePage(event,"data_sampah_keluar");
    }

    @FXML
    void OnDataPengelompokan(ActionEvent event) {
        Helper.changePage(event,"data_pengelompokan_sampah");
    }

    @FXML
    void OnDataSampahMenu(ActionEvent event) {
        Helper.changePage(event,"menu_data_sampah");
    }

    @FXML
    void OnLogout(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void OnMitraMenu(ActionEvent event) {
        Helper.changePage(event,"menu_mitra");
    }

    @FXML
    void OnPermintaanMenu(ActionEvent event) {
        Helper.changePage(event,"menu_permintaan");
    }

    @FXML
    void OnProfilTPAMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

}
