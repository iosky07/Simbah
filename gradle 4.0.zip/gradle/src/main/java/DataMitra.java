import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DataMitra implements Initializable {

    @FXML
    private TableView<TabelDataMitra> table_data_mitra;

    @FXML
    private TableColumn<TabelDataMitra, String> col_id_mitra;

    @FXML
    private TableColumn<TabelDataMitra, String> col_nama_mitra;

    @FXML
    private TableColumn<TabelDataMitra, Integer> col_kecamatan;

    @FXML
    private TableColumn<TabelDataMitra, String> col_ketua;

    @FXML
    private TableColumn<TabelDataMitra, String> col_alamat;

    @FXML
    private Button logout;

    @FXML
    private Button datasampah;

    @FXML
    private Button permintaan;

    @FXML
    private Button mitra;

    @FXML
    private Button tambahMitra;

    @FXML
    private Button editMitra;

    @FXML
    private Button menuProfil;

    @FXML
    private Button dashboard;

    @FXML
    void OnDashboard(ActionEvent event) {
        Helper.changePage(event,"dashboard");
    }

    @FXML
    void OnDataSampahMenu(ActionEvent event) {
        Helper.changePage(event,"menu_data_sampah");
    }

    @FXML
    void OnEditMitra(ActionEvent event) {
        Helper.changePage(event,"edit_mitra");
    }

    @FXML
    void OnLogout(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void OnMitraMenu(ActionEvent event) {
        Helper.changePage(event,"menu_mitra");
    }

    @FXML
    void OnPermintaanMenu(ActionEvent event) {
        Helper.changePage(event,"menu_permintaan");
    }

    @FXML
    void OnProfilTPAMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

    @FXML
    void OnTambahMitra(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

    ObservableList<TabelDataMitra> ListM;

    int index = -1;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement ps = null;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        col_id_mitra.setCellValueFactory(new PropertyValueFactory<TabelDataMitra, String>("id"));
        col_nama_mitra.setCellValueFactory(new PropertyValueFactory<TabelDataMitra, String>("mitra"));
        col_ketua.setCellValueFactory(new PropertyValueFactory<TabelDataMitra, String>("ketua"));
        col_kecamatan.setCellValueFactory(new PropertyValueFactory<TabelDataMitra, Integer>("kecamatan"));
        col_alamat.setCellValueFactory(new PropertyValueFactory<TabelDataMitra, String>("alamat"));

        ObservableList<TabelDataMitra> listM = null;
        try {
            listM = GetDataTabel.getDataMitra();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        table_data_mitra.setItems(listM);
    }

}
