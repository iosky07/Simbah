import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class GetDataTabel {

    public static ObservableList<TabelDataSampah> getDataDashboard() {

//        Connection conn = Helper.getConnection();
        ObservableList<TabelDataSampah> list = FXCollections.observableArrayList();

//            PreparedStatement ps = conn.prepareStatement()
        ResultSet rs = Helper.execute("Select * from datasampah");
        while (true) {
            try {
                if (!rs.next()) break;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            try {
//                int kecamatan, int jumlah, String nama, String id, String noTruk, String tanggal

                list.add(new TabelDataSampah(
                        Integer.parseInt(rs.getString("id_kecamatan")),
                        Integer.parseInt(rs.getString("jumlah_sm")),
                        rs.getString("nama_tpa"),
                        rs.getString("id_sm"),
                        rs.getString("no_truk"),
                        rs.getString("tanggal_masuk")
                ));
//                System.out.println(rs.getString("tanggal_masuk"));
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return list;
    }

    public static ObservableList<TabelDataMitra> getDataMitra() throws SQLException {

        ObservableList<TabelDataMitra> list = FXCollections.observableArrayList();

        ResultSet rs = Helper.execute("select * from datamitra");
        while (rs.next()){

//            int kecamatan, String id, String mitra, String ketua, String alamat
            try { list.add(new TabelDataMitra(
                    Integer.parseInt(rs.getString("id_kecamatan")),
                    rs.getString("id_mitra"),
                    rs.getString("nama_mitra"),
                    rs.getString("ketua"),
                    rs.getString("alamat")
            ));
            } catch (SQLException throwables){
                throwables.printStackTrace();
            }
        }

        return list;
    }
}