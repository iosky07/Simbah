import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class UbahPassAlertDataKosongM {

    @FXML
    private Button alertOK;

    @FXML
    void AlertOK(ActionEvent event) {
        Helper.changePage(event,"ubah_pass_m");
    }

}
