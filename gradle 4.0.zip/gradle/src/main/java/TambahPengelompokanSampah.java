import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class TambahPengelompokanSampah {

    @FXML
    private Button masukkanData;

    @FXML
    private Button batalMasukkan;

    @FXML
    void Batal(ActionEvent event) {
        Helper.changePage(event,"data_pengelompokan_sampah");
    }

    @FXML
    void Simpan(ActionEvent event) {
        Helper.changePage(event,"data_pengelompokan_sampah");
    }

}
