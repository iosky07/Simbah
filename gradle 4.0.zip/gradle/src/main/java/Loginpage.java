import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Loginpage {

    @FXML
    private Button btnmasuk;

    @FXML
    private Button switchMitra;

    @FXML
    void OnMitraLogin(ActionEvent event) {
        Helper.changePage(event,"loginpage_m");
    }

    @FXML
    void masukDashboard(ActionEvent event) {
        Helper.changePage(event,"dashboard");
    }

}

