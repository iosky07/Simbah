import com.mysql.jdbc.Connection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class DataJumlahSampah implements Initializable {

    @FXML
    private Button logout;

    @FXML
    private Button datasampah;

    @FXML
    private Button permintaan;

    @FXML
    private Button menuProfil;

    @FXML
    private Button mitra;

    @FXML
    private Button dashboard;

    @FXML
    void OnDashboard(ActionEvent event) {
        Helper.changePage(event,"dashboard");
    }

    @FXML
    void OnDataSampahMenu(ActionEvent event) {
        Helper.changePage(event,"menu_data_sampah");
    }

    @FXML
    void OnLogout(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void OnMitraMenu(ActionEvent event) {

        Helper.changePage(event,"menu_mitra");
    }

    @FXML
    void OnPermintaanMenu(ActionEvent event) {

        Helper.changePage(event,"menu_permintaan");
    }

    @FXML
    void OnProfilTPAMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ResultSet rs = Helper.execute( "SELECT * FROM `datasampah`");
        while(true){
            try {
                if (!rs.next()) break;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            try {
                System.out.println(rs.getString("id_sm"));
                System.out.println(rs.getString("nama_tpa"));
                System.out.println(rs.getString("tanggal_masuk"));
                System.out.println(rs.getString("jumlah_sm"));
                System.out.println(rs.getString("no_truk"));
                System.out.println(rs.getString("id_kecamatan"));
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        }
    }
}
