//import javafx.event.ActionEvent;
//
//public class Dashboard {
//    public void tombol(ActionEvent event){
//        Helper.changePage(event,"dashboard");
//    }
//}

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Dashboard {

    @FXML
    private Button tambahData;

    @FXML
    private Button editSampah;

    @FXML
    private Button logout;

    @FXML
    private Button datasampah;

    @FXML
    private Button permintaan;

    @FXML
    private Button menuProfil;

    @FXML
    private Button mitra;

    @FXML
    void OnDataSampahMenu(ActionEvent event) {
        Helper.changePage(event,"menu_data_sampah");
    }

    @FXML
    void OnEditSampah(ActionEvent event) {
        Helper.changePage(event,"edit_sampah_dashboard");
    }

    @FXML
    void OnLogout(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void OnMitraMenu(ActionEvent event) { Helper.changePage(event,"menu_mitra"); }

    @FXML
    void OnPermintaanMenu(ActionEvent event) {
        Helper.changePage(event,"menu_permintaan");
    }

    @FXML
    void OnProfilTPAMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

    @FXML
    void OnTambahSampah(ActionEvent event) {
        Helper.changePage(event,"tambah_sampah_dashboard");
    }

}
