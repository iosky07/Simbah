
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Helper {
    public static void changePage(Event event, String viewName) {
        Node node = (Node) event.getSource();
        Scene oldScene = node.getScene();
        Stage stage = (Stage) oldScene.getWindow();


        try {
            Parent view = FXMLLoader.load(Helper.class.getResource(  viewName + ".fxml"));
            Scene newScene = new Scene(view);
            stage.setScene(newScene);
            stage.show();
        } catch (IOException e) {
            System.err.println("View Tidak Ditemukan");
            e.printStackTrace();
        }
    }


    // HOST, username, password, nama database
    private static final String HOST = "127.0.0.1";
    private static final String DATABASE = "latihan";

    public static Connection getConnection() {
        try {
            Class.forName("Exception in Application start method");
            String url = String.format("jdbc:mysql://%s/%s", HOST, DATABASE);
            Connection connection = DriverManager.getConnection(url, "miqdad", "a");
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}