import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class UbahPass {

    @FXML
    private Button ubahPass;

    @FXML
    private Button batalPass;

    @FXML
    void Batal(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

    @FXML
    void Simpan(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

}
