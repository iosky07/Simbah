import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class EditProduksiSampahM {

    @FXML
    private Button batalMasukkan;

    @FXML
    private Button masukkanData;

    @FXML
    void Batal(ActionEvent event) {
        Helper.changePage(event,"data_produksi_sampah_m");
    }

    @FXML
    void Simpan(ActionEvent event) {
        Helper.changePage(event,"data_produksi_sampah_m");
    }

}
