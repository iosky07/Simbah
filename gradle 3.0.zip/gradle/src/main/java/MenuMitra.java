import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MenuMitra {

    @FXML
    private Button logout;

    @FXML
    private Button datasampah;

    @FXML
    private Button permintaan;

    @FXML
    private Button mitra;

    @FXML
    private Button dataMitra;

    @FXML
    private Button dataProduk;

    @FXML
    private Button menuProfil;

    @FXML
    private Button dashboard;

    @FXML
    void OnDashboard(ActionEvent event) {
        Helper.changePage(event,"dashboard");
    }

    @FXML
    void OnDataMitra(ActionEvent event) {
        Helper.changePage(event,"data_mitra");
    }

    @FXML
    void OnDataProduksi(ActionEvent event) {
        Helper.changePage(event,"data_produksi_sampah");
    }

    @FXML
    void OnDataSampahMenu(ActionEvent event) {
        Helper.changePage(event,"menu_data_sampah");
    }

    @FXML
    void OnLogout(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void OnMitraMenu(ActionEvent event) {
        Helper.changePage(event,"menu_mitra");
    }

    @FXML
    void OnPermintaanMenu(ActionEvent event) {
        Helper.changePage(event,"menu_permintaan");
    }

    @FXML
    void OnProfilTPAMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_tpa");
    }

}
