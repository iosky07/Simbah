import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class UbahPassM {

    @FXML
    private Button ubahPass;

    @FXML
    private Button batalPass;

    @FXML
    void Batal(ActionEvent event) {
        Helper.changePage(event,"menu_profil_mitra_m");
    }

    @FXML
    void Simpan(ActionEvent event) {
        Helper.changePage(event,"menu_profil_mitra_m");
    }

}
