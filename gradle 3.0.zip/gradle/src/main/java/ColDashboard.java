public class ColDashboard {

    int tanggal, kecamatan, jumlah;
    String nama, id, noTruk;

    public ColDashboard(int tanggal, int kecamatan, int jumlah, String nama, String id, String noTruk) {
        this.tanggal = tanggal;
        this.kecamatan = kecamatan;
        this.jumlah = jumlah;
        this.nama = nama;
        this.id = id;
        this.noTruk = noTruk;
    }

    public int getTanggal() {
        return tanggal;
    }

    public int getKecamatan() {
        return kecamatan;
    }

    public int getJumlah() {
        return jumlah;
    }

    public String getNama() {
        return nama;
    }

    public String getId() {
        return id;
    }

    public String getNoTruk() {
        return noTruk;
    }

    public void setTanggal(int tanggal) {
        this.tanggal = tanggal;
    }

    public void setKecamatan(int kecamatan) {
        this.kecamatan = kecamatan;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNoTruk(String noTruk) {
        this.noTruk = noTruk;
    }
}
