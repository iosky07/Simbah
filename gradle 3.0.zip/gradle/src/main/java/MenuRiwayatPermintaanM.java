import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MenuRiwayatPermintaanM {

    @FXML
    private Button statusPermintaanM;

    @FXML
    private Button riwayatTransaksiM;

    @FXML
    private Button logoutM;

    @FXML
    private Button datasampahM;

    @FXML
    private Button permintaanM;

    @FXML
    private Button menuProfilM;

    @FXML
    private Button produksiM;

    @FXML
    void OnDataProduksiM(ActionEvent event) {
        Helper.changePage(event,"data_produksi_sampah_m");
    }

    @FXML
    void OnDataSampahM(ActionEvent event) {
        Helper.changePage(event,"data_sampah_m");
    }

    @FXML
    void OnLogoutM(ActionEvent event) {
        Helper.changePage(event,"loginpage");
    }

    @FXML
    void OnProfilMitraMenu(ActionEvent event) {
        Helper.changePage(event,"menu_profil_mitra_m");
    }

    @FXML
    void OnRiwayatMenuM(ActionEvent event) {
        Helper.changePage(event,"menu_riwayat_permintaan_m");
    }

    @FXML
    void OnRiwayatTransaksiM(ActionEvent event) {
        Helper.changePage(event,"data_riwayat_transaksi_m");
    }

    @FXML
    void OnStatusPermintaanM(ActionEvent event) {
        Helper.changePage(event,"data_status_permintaan_m");
    }

}
