import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javax.swing.*;
import java.sql.*;

public class GetDataTabel {

    public static ObservableList<ColDashboard> getDataDashboard() {

//        Connection conn = Helper.getConnection();
        ObservableList<ColDashboard> list = FXCollections.observableArrayList();

//            PreparedStatement ps = conn.prepareStatement()
        ResultSet rs = Helper.execute("Select * from datasampah");
        while (true) {
            try {
                if (!rs.next()) break;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            try {
                list.add(new ColDashboard(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("nama")), Integer.parseInt(rs.getString("kecamatan")), rs.getString("tanggal"), rs.getString("jumlah"), rs.getString("noTruk")));
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return list;
    }
}